package com.google.pizza3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class OrderScreen extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_screen);

        Intent callIntent = getIntent();
        //String str = callIntent.getStringExtra("specialChoice");
        //Toast.makeText(this, "string", Toast.LENGTH_SHORT).show();

        TextView pizza = (TextView) findViewById(R.id.selected_pizza);
        pizza.setText(getIntent().getStringExtra("specialChoice"));

        //Toast.makeText(this, selectedPizza, Toast.LENGTH_SHORT).show();

        //TextView pizzaCost = (TextView) findViewById(R.id.selected_pizza_cost);
        //pizzaCost.setText(getIntent().getStringExtra("specialChoicePrice"));

        /*
        String rawCost = (getIntent().getStringExtra("specialChoicePrice"));
        double value = Double.parseDouble(rawCost);

        TextView pizzaCostS = (TextView) findViewById(R.id.selected_pizza_costS);
        String stringdouble= Double.toString(value);
        pizzaCostS.setText("$"+stringdouble);
        */
    }

    public void confirmOrder(View view) {
        String selectedPizza = (getIntent().getStringExtra("specialChoice"));
        Toast.makeText(this, "You have successfully ordered a "+selectedPizza, Toast.LENGTH_LONG).show();
        Intent d = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(d);
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
