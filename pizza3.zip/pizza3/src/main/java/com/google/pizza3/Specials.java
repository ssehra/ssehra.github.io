package com.google.pizza3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

public class Specials extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specials);
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    String pizza;
    String pizzaCost;

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch (view.getId()) {
            case R.id.canada_pizza:
                if (checked)
                    pizza = "Special Canada's Favorite Pizza";
                    pizzaCost = "13.49";
                break;
            case R.id.italy_pizza:
                if (checked)
                    pizza = "Special Italian Style Pizza";
                    pizzaCost = "13.99";
                break;
            case R.id.mexican_pizza:
                if (checked)
                    pizza = "Special Mexican Style Pizza";
                    pizzaCost = "15.99";
                break;
            case R.id.veg_pizza:
                if (checked)
                    pizza = "Special Veggie Garden Pizza";
                    pizzaCost = "12.99";
                break;
            case R.id.cheese_pizza:
                if (checked)
                    pizza = "Special Cheeseist Pizza";
                    pizzaCost = "10.99";
                break;
        }
    }

    public void specialContinue(View view) {
        if (pizza == null) {
            Toast.makeText(this, "You must select a pizza before continuing", Toast.LENGTH_SHORT).show();
        }
        else {
            Intent c = new Intent(this, OrderScreen.class);
            c.putExtra("specialChoice", pizza);
            c.putExtra("specialChoicePrice", pizzaCost);
            startActivity(c);
        }
    }
}
