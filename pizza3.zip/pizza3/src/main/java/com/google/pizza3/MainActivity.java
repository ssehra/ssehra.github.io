package com.google.pizza3;

import android.content.DialogInterface;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        android.support.v7.app.ActionBar ab = getSupportActionBar();
        ab.setLogo(R.mipmap.ic_launcher);
        ab.setDisplayUseLogoEnabled(true);
        ab.setDisplayShowHomeEnabled(true);
    }

    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setIcon(R.drawable.ic_sad_exit)
                .setTitle("Exit Confirmation")
                .setMessage("Are you sure you want to exit this application?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }

                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    public void customPizza(View view) {
        Toast.makeText(this, "You selected Custom\nneeds implementation...", Toast.LENGTH_SHORT).show();
        Intent a = new Intent(getApplicationContext(),AuthorScreen.class);
        startActivity(a);
    }

    public void specialPizza(View view) {
        Intent b = new Intent(getApplicationContext(),Specials.class);
        startActivity(b);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId())
        {
            case R.id.pizza:
                Toast.makeText(this, "Redirecting to Domino's Pizza", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.dominos.ca/"));
                startActivity(i);
                break;
            case R.id.author:
                Intent j = new Intent(getApplicationContext(),AuthorScreen.class);
                startActivity(j);
                break;
            case R.id.help:
                Toast.makeText(this, "Redirecting to Humber College", Toast.LENGTH_SHORT).show();
                Intent k = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.humber.ca/"));
                startActivity(k);
                break;
        }

        return super.onOptionsItemSelected(item);
    }
}
