package com.google.pizza3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

//public class AuthorScreen extends AppCompatActivity {
public class AuthorScreen extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_author_screen);
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
